FW VERSION MANAGER - RHINO 8 FOR WINDOWS

Switches the Frailey Woodworks Toolkit to any published version, including
old versions that have no version picker of their own. It is a separate
plug-in, so it stays available whichever Toolkit version is loaded.

SETUP
1. Extract the entire ZIP to a folder you will keep.
2. In Rhino 8, drag net7.0\FWVersionManager.rhp into the Rhino window.
   (Only if Rhino was started in .NET Framework mode, use net48 instead.)
3. Type FWVersionManager to open the panel.

USE
- The list shows every published Toolkit version, newest first, marked
  Stable or Dev. Untick "Show development builds" to see stable only.
- Pick a version and press "Install selected version". It is downloaded,
  checked against the publisher's signature, and set to load the NEXT time
  you start Rhino. Rhino is never closed for you.
- The chosen version stays pinned until you choose another one or press
  "Return to latest stable".

No GitHub account is needed. Nothing is installed unless its signature and
checksums match.
