FW BLUEPRINT PLUGIN - RHINO 8 FOR WINDOWS

No GitHub account or source-code access is needed.

FIRST INSTALL
1. Download the official ZIP, then extract it to a folder you will keep.
2. Save your Rhino work. Drag net7.0/FWBlueprintPlugin.rhp from the extracted folder into Rhino 8.
3. Run BlueprintUpdates to view the installed version and update controls.

FUTURE UPDATES
Automatic updates are enabled by default. After the plugin loads, it makes one background check, with at most one automatic attempt per 12 hours. A verified newer version is downloaded to your local user folder and selected for the next normal Rhino start. Save and restart Rhino whenever convenient. No restart is forced.

BlueprintUpdates offers Check now, Cancel check, the automatic-update switch, and Use previous version next start. Rollback pauses automatic updates so the previous version can remain selected. Re-enable them when ready.

Failed, offline, cancelled or damaged downloads keep the current installation. Open models, drawing annotations, saved preferences and Google title-page credentials are not rewritten by the updater. The Google title-page connection is separate; each user supplies their own authorized Google connection if they want that feature.

Only Windows Rhino 8 is supported by this package. Rhino supplies RhinoCommon and Eto; do not copy those assemblies into this folder. Keep the whole extracted package together. The net48 folder supports Rhino's .NET Framework runtime; the default Rhino 8 runtime uses net7.0.
