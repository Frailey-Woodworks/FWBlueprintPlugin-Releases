FRAILEY WOODWORKS TOOLKIT - RHINO 8 FOR WINDOWS

SETUP
1. Extract the entire ZIP to a folder you will keep.
2. In Rhino 8, drag net7.0\FWBlueprintPlugin.rhp into the Rhino window.
3. Type FWToolkit to open the tools, or FWToolkitUpdates for updates.

Keep every support file with the plugin. The old filename is retained for
compatibility. Existing BlueprintPanel and BlueprintUpdates commands still work.

UPDATES
Automatic updates are on by default. A verified newer release downloads in the
background and loads after your next normal Rhino restart. Nothing forces a
restart. Check and download update is also available on the Updates tab.
Automatic checks occur once at startup, at most once per 12 hours.

No GitHub account, source-code access, developer tools or administrator account
is required. Offline or failed downloads keep the current installation.

Windows Rhino 8 only. The net48 folder supports Rhino's optional Framework
runtime; the default runtime uses net7.0. Keep the full package together.
Google title-page import is optional and requires your own Google authorization;
no account keys, project workbook or personal preferences are included.
